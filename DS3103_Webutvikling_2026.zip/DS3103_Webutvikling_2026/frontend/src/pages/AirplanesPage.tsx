import { useState } from 'react';
import { useAirplanes } from '../contexts/AirplaneContext';
import { AirplaneList } from '../components/airplanes/AirplaneList';
import { AirplaneForm } from '../components/airplanes/AirplaneForm';
import { IAirplane } from '../interfaces/IAirplane';
import { Button } from '../components/shared/button';
import { Input } from '../components/shared/input';
import { Search } from 'lucide-react';
import { toast } from 'sonner';

export const HomePage = () => {
  const {
    airplanes,
    loading,
    error,
    searchAirplanes,
    updateAirplane,
    deleteAirplane,
  } = useAirplanes();

  const [showForm, setShowForm] = useState(false);
  const [editingAirplane, setEditingAirplane] = useState<IAirplane | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await searchAirplanes(searchTerm);
    } catch {
      toast.error('Failed to search airplanes');
    }
  };

  const handleEdit = (airplane: IAirplane) => {
    setEditingAirplane(airplane);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteAirplane(id);
      toast.success('Airplane deleted');
    } catch {
      toast.error('Failed to delete airplane');
    }
  };

  const handleSubmit = async (airplane: IAirplane, imageFile?: File) => {
    try {
      if (editingAirplane && editingAirplane.id) {
        await updateAirplane(editingAirplane.id, airplane, imageFile);
        toast.success('Airplane updated');
      }
      setShowForm(false);
      setEditingAirplane(null);
    } catch {
      toast.error('Failed to save airplane');
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingAirplane(null);
  };

  return (
    <>
      <div className="sticky top-16 z-30 bg-background/95 backdrop-blur-sm border-b border-border/40">
        <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <form onSubmit={handleSearch} className="flex gap-2" role="search" aria-label="Search airplanes">
            <div className="relative flex-1">
              <Search
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4"
                aria-hidden="true"
              />
              <Input
                type="text"
                placeholder="Search by model name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 h-10 bg-card border-border/60"
                aria-label="Search airplanes by model name"
              />
            </div>
            <Button type="submit" variant="secondary" className="h-10 px-5">
              Search
            </Button>
          </form>
        </div>
      </div>

      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {error && (
          <div
            className="bg-destructive/5 border border-destructive/20 text-destructive px-4 py-3 rounded-xl mb-6"
            role="alert"
          >
            <p className="text-sm">{error}</p>
          </div>
        )}

        <AirplaneList
          airplanes={airplanes}
          loading={loading}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />

        {showForm && (
          <AirplaneForm
            airplane={editingAirplane}
            onSubmit={handleSubmit}
            onCancel={handleCancel}
          />
        )}
      </div>
    </>
  );
};
