import { Outlet, Link, useLocation } from 'react-router';
import { Plane, Home, PlusCircle } from 'lucide-react';

export const Layout = () => {
    const location = useLocation();

    const navLinks = [
        { to: '/', label: 'Home', icon: Home },
        { to: '/add', label: 'Add airplane', icon: PlusCircle },
    ];

    return (
        <div className="min-h-screen bg-background flex flex-col">
            <a
                href="#main-content"
                className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-[100] focus:bg-primary focus:text-primary-foreground focus:px-4 focus:py-2 focus:rounded-lg focus:outline-none"
            >
                Skip to main content
            </a>
            <header className="bg-card border-b border-border/60 sticky top-0 z-40 backdrop-blur-sm bg-card/95">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">
                        <Link to="/" className="flex items-center gap-3 group" aria-label="AirIndustries Home">
                            <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center group-hover:bg-primary/90 transition-colors">
                                <Plane className="w-5 h-5 text-primary-foreground" aria-hidden="true" />
                            </div>
                            <div>
                                <span className="text-foreground tracking-tight block leading-none">AirIndustries</span>
                                <span className="text-muted-foreground text-xs mt-0.5 block">Administration</span>
                            </div>
                        </Link>
                        <nav aria-label="Main navigation">
                            <ul className="flex items-center gap-1">
                                {navLinks.map((link) => {
                                    const Icon = link.icon;
                                    const isActive = location.pathname === link.to;
                                    return (
                                        <li key={link.to}>
                                            <Link
                                                to={link.to}
                                                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ${isActive
                                                    ? 'bg-primary text-primary-foreground'
                                                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                                                    }`}
                                                aria-current={isActive ? 'page' : undefined}
                                            >
                                                <Icon className="w-4 h-4" aria-hidden="true" />
                                                <span className="hidden sm:inline">{link.label}</span>
                                            </Link>
                                        </li>
                                    );
                                })}
                            </ul>
                        </nav>
                    </div>
                </div>
            </header>
            <main id="main-content" className="flex-1" tabIndex={-1}>
                <Outlet />
            </main>
            <footer className="border-t border-border/60 mt-auto">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
                    <p className="text-center text-muted-foreground text-xs">
                        DS3103 Webutvikling Exam &middot; AirIndustries
                    </p>
                </div>
            </footer>
        </div>
    );
};