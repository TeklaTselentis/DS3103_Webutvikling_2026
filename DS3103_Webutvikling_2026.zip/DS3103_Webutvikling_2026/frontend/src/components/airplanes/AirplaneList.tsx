import { IAirplane } from '../../interfaces/IAirplane';
import { AirplaneItem } from './AirplaneItem';
import { Plane } from 'lucide-react';

interface AirplaneListProps {
  airplanes: IAirplane[];
  loading: boolean;
  onEdit: (airplane: IAirplane) => void;
  onDelete: (id: number) => void;
}

export const AirplaneList = ({
  airplanes,
  loading,
  onEdit,
  onDelete,
}: AirplaneListProps) => {
  if (loading) {
    return (
      <div
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        role="status"
        aria-label="Loading airplanes"
      >
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-card rounded-2xl border border-border/60 overflow-hidden animate-pulse">
            <div className="h-48 bg-muted" />
            <div className="p-5 space-y-3">
              <div className="h-5 bg-muted rounded-lg w-3/4" />
              <div className="h-4 bg-muted rounded-lg w-1/2" />
              <div className="h-4 bg-muted rounded-lg w-1/3" />
              <div className="flex gap-2 pt-2">
                <div className="h-8 bg-muted rounded-lg flex-1" />
                <div className="h-8 bg-muted rounded-lg w-10" />
              </div>
            </div>
          </div>
        ))}
        <span className="sr-only">Loading airplanes...</span>
      </div>
    );
  }

  if (airplanes.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-5">
          <Plane className="w-7 h-7 text-muted-foreground" aria-hidden="true" />
        </div>
        <h3 className="text-foreground mb-1">No airplanes found</h3>
        <p className="text-sm text-muted-foreground max-w-sm">
          Add your first airplane to get started, or adjust your search criteria.
        </p>
      </div>
    );
  }

  return (
    <div
      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
      role="list"
      aria-label="List of airplanes"
    >
      {airplanes.map((airplane) => (
        <div key={airplane.id} role="listitem">
          <AirplaneItem airplane={airplane} onEdit={onEdit} onDelete={onDelete} />
        </div>
      ))}
    </div>
  );
};