import { useState } from 'react';
import { IAirplane } from '../../interfaces/IAirplane';
import { Pencil, Trash2, Users, ChevronRight } from 'lucide-react';
import { Button } from '../shared/button';

interface AirplaneItemProps {
  airplane: IAirplane;
  onEdit: (airplane: IAirplane) => void;
  onDelete: (id: number) => void;
}

const CATEGORY_STYLES: Record<string, string> = {
  Travel: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  Military: 'bg-red-50 text-red-700 border-red-200',
  'Private Jet': 'bg-violet-50 text-violet-700 border-violet-200',
  Cargo: 'bg-amber-50 text-amber-700 border-amber-200',
  Training: 'bg-sky-50 text-sky-700 border-sky-200',
};

export const AirplaneItem = ({ airplane, onEdit, onDelete }: AirplaneItemProps) => {
  const [imgError, setImgError] = useState(false);

  const imageUrl = imgError || !airplane.image
    ? ''
    : airplane.image.startsWith('http')
      ? airplane.image
      : `http://localhost:5000/images/${airplane.image}`;

  const categoryStyle =
    CATEGORY_STYLES[airplane.category] || 'bg-gray-50 text-gray-700 border-gray-200';

  return (
    <div className="group bg-card rounded-2xl border border-border/60 overflow-hidden hover:border-border hover:shadow-lg hover:shadow-black/5 transition-all duration-300">
      <div className="relative h-48 bg-muted overflow-hidden">
        <img
          src={imageUrl}
          alt={`${airplane.modelName}`}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          onError={() => setImgError(true)}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        <div className="absolute top-3 left-3">
          <span className={`inline-flex items-center text-xs px-2.5 py-1 rounded-full border backdrop-blur-sm ${categoryStyle}`}>
            {airplane.category}
          </span>
        </div>
      </div>

      <div className="p-5">
        <div className="flex items-start justify-between gap-2 mb-3">
          <h3 className="text-foreground truncate">{airplane.modelName}</h3>
          <ChevronRight
            className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0 mt-1"
            aria-hidden="true"
          />
        </div>

        <div className="flex items-center text-muted-foreground mb-5">
          <Users className="w-3.5 h-3.5 mr-1.5" aria-hidden="true" />
          <span className="text-sm">
            {airplane.passengers.toLocaleString()} passenger{airplane.passengers !== 1 ? 's' : ''}
          </span>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={() => onEdit(airplane)}
            variant="outline"
            size="sm"
            className="flex-1 rounded-lg"
            aria-label={`Edit ${airplane.modelName}`}
          >
            <Pencil className="w-3.5 h-3.5" aria-hidden="true" />
            Edit
          </Button>
          <Button
            onClick={() => {
              if (airplane.id && window.confirm(`Delete ${airplane.modelName}?`)) {
                onDelete(airplane.id);
              }
            }}
            variant="ghost"
            size="sm"
            className="rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/5"
            aria-label={`Delete ${airplane.modelName}`}
          >
            <Trash2 className="w-3.5 h-3.5" aria-hidden="true" />
          </Button>
        </div>
      </div>
    </div>
  );
};
