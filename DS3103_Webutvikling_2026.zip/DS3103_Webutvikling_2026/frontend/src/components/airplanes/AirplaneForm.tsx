import { useState, useEffect } from 'react';
import { IAirplane } from '../../interfaces/IAirplane';
import { Button } from '../shared/button';
import { Input } from '../shared/input';
import { Label } from '../shared/label';
import { X, Image as ImageIcon } from 'lucide-react';

const CATEGORIES = ['Military', 'Travel', 'Private Jet', 'Cargo', 'Training'];

interface AirplaneFormProps {
  airplane?: IAirplane | null;
  onSubmit: (airplane: IAirplane, imageFile?: File) => Promise<void>;
  onCancel: () => void;
}

export const AirplaneForm = ({ airplane, onSubmit, onCancel }: AirplaneFormProps) => {
  const [modelName, setModelName] = useState('');
  const [category, setCategory] = useState('');
  const [passengers, setPassengers] = useState<number>(0);
  const [imageFile, setImageFile] = useState<File | undefined>(undefined);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (airplane) {
      setModelName(airplane.modelName);
      setCategory(airplane.category);
      setPassengers(airplane.passengers);
      if (airplane.image) {
        setImagePreview(
          airplane.image.startsWith('http')
            ? airplane.image
            : `http://localhost:5000/images/${airplane.image}`
        );
      }
    } else {
      resetForm();
    }
  }, [airplane]);

  const resetForm = () => {
    setModelName('');
    setCategory('');
    setPassengers(0);
    setImageFile(undefined);
    setImagePreview('');
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await onSubmit({ modelName, category, passengers, image: airplane?.image || '' }, imageFile);
      resetForm();
    } catch (err) {
      console.error('Error submitting form:', err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 z-50"
      onClick={(e) => e.target === e.currentTarget && onCancel()}
      role="dialog"
      aria-modal="true"
      aria-label={airplane ? 'Edit airplane' : 'Add airplane'}
    >
      <div className="bg-card rounded-2xl border border-border/60 shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center px-6 py-5 border-b border-border/60">
          <div>
            <h2 className="text-foreground">
              {airplane ? 'Edit airplane' : 'Add airplane'}
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {airplane ? 'Update the airplane details below' : 'Fill in the details to register a new airplane'}
            </p>
          </div>
          <button
            onClick={onCancel}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            aria-label="Close form"
          >
            <X className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="space-y-5">
            <div className="space-y-1.5">
              <Label htmlFor="edit-modelName" className="text-sm">
                Model Name <span className="text-destructive" aria-hidden="true">*</span>
              </Label>
              <Input
                id="edit-modelName"
                type="text"
                value={modelName}
                onChange={(e) => setModelName(e.target.value)}
                required
                placeholder="e.g., TeslaPlane-1"
                className="h-10 bg-background border-border/60"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="edit-category" className="text-sm">
                Category <span className="text-destructive" aria-hidden="true">*</span>
              </Label>
              <div className="flex flex-wrap gap-2 mb-2" role="group" aria-label="Preset categories">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    aria-pressed={category === cat}
                    className={`text-xs px-3 py-1.5 rounded-full border transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ${
                      category === cat
                        ? 'bg-primary text-primary-foreground border-primary'
                        : 'bg-card text-muted-foreground border-border/60 hover:border-border hover:text-foreground'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              <Input
                id="edit-category"
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                required
                placeholder="Or type a custom category..."
                className="h-10 bg-background border-border/60"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="edit-passengers" className="text-sm">
                Passengers <span className="text-destructive" aria-hidden="true">*</span>
              </Label>
              <Input
                id="edit-passengers"
                type="number"
                value={passengers}
                onChange={(e) => setPassengers(parseInt(e.target.value) || 0)}
                required
                min="0"
                placeholder="e.g., 150"
                className="h-10 bg-background border-border/60"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="edit-image" className="text-sm">Airplane Image</Label>
              {imagePreview ? (
                <div className="relative rounded-xl overflow-hidden border border-border/60">
                  <img
                    src={imagePreview}
                    alt="Preview of airplane image"
                    className="w-full h-40 object-cover"
                  />
                  <div className="absolute inset-0 bg-black/0 hover:bg-black/40 transition-colors flex items-center justify-center group">
                    <label
                      htmlFor="edit-image"
                      className="opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer bg-white/90 text-foreground text-xs px-3 py-1.5 rounded-lg"
                    >
                      Change Image
                    </label>
                  </div>
                </div>
              ) : (
                <label
                  htmlFor="edit-image"
                  className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-border/60 rounded-xl cursor-pointer hover:border-primary/30 hover:bg-accent/50 transition-colors"
                >
                  <ImageIcon className="w-6 h-6 text-muted-foreground mb-2" aria-hidden="true" />
                  <span className="text-sm text-muted-foreground">Click to upload image</span>
                  <span className="text-xs text-muted-foreground/60 mt-0.5">PNG, JPG up to 5MB</span>
                </label>
              )}
              <Input
                id="edit-image"
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
                aria-label="Upload airplane image"
              />
            </div>
          </div>

          <div className="flex gap-3 mt-7 pt-5 border-t border-border/60">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="flex-1 h-10 rounded-xl"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="flex-1 h-10 rounded-xl"
              disabled={submitting}
            >
              {submitting ? 'Saving...' : airplane ? 'Update airplane' : 'Add airplane'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
