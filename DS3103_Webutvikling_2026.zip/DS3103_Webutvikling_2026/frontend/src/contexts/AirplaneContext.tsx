import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { IAirplane } from '../interfaces/IAirplane';
import AirplaneService from '../services/AirplaneService';

interface AirplaneContextType {
  airplanes: IAirplane[];
  loading: boolean;
  error: string | null;
  fetchAirplanes: () => Promise<void>;
  getAirplaneById: (id: number) => Promise<IAirplane | null>;
  searchAirplanes: (modelName: string) => Promise<void>;
  createAirplane: (airplane: IAirplane, imageFile?: File) => Promise<void>;
  updateAirplane: (id: number, airplane: IAirplane, imageFile?: File) => Promise<void>;
  deleteAirplane: (id: number) => Promise<void>;
}

const AirplaneContext = createContext<AirplaneContextType | undefined>(undefined);

export const AirplaneProvider = ({ children }: { children: ReactNode }) => {
  const [airplanes, setAirplanes] = useState<IAirplane[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchAirplanes = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await AirplaneService.getAll();
      setAirplanes(data);
    } catch (err) {
      setError('Could not load airplanes. Is the backend running?');
    } finally {
      setLoading(false);
    }
  };

  const getAirplaneById = async (id: number): Promise<IAirplane | null> => {
    try {
      return await AirplaneService.getById(id);
    } catch (err) {
      setError('Failed to fetch airplane');
      return null;
    }
  };

  const searchAirplanes = async (modelName: string) => {
    setLoading(true);
    setError(null);
    try {
      if (modelName.trim() === '') {
        await fetchAirplanes();
      } else {
        const data = await AirplaneService.getByModelName(modelName);
        setAirplanes(data);
      }
    } catch (err) {
      setError('Failed to search airplanes');
    } finally {
      setLoading(false);
    }
  };

  const createAirplane = async (airplane: IAirplane, imageFile?: File) => {
    setLoading(true);
    setError(null);
    try {
      await AirplaneService.create(airplane, imageFile);
      await fetchAirplanes();
    } catch (err) {
      setError('Failed to create airplane');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const updateAirplane = async (id: number, airplane: IAirplane, imageFile?: File) => {
    setLoading(true);
    setError(null);
    try {
      await AirplaneService.update(id, airplane, imageFile);
      await fetchAirplanes();
    } catch (err) {
      setError('Failed to update airplane');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const deleteAirplane = async (id: number) => {
    setLoading(true);
    setError(null);
    try {
      await AirplaneService.delete(id);
      await fetchAirplanes();
    } catch (err) {
      setError('Failed to delete airplane');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAirplanes();
  }, []);

  return (
    <AirplaneContext.Provider
      value={{
        airplanes,
        loading,
        error,
        fetchAirplanes,
        getAirplaneById,
        searchAirplanes,
        createAirplane,
        updateAirplane,
        deleteAirplane,
      }}
    >
      {children}
    </AirplaneContext.Provider>
  );
};

export const useAirplanes = (): AirplaneContextType => {
  const context = useContext(AirplaneContext);
  if (!context) {
    throw new Error('useAirplanes must be used within an AirplaneProvider');
  }
  return context;
};
