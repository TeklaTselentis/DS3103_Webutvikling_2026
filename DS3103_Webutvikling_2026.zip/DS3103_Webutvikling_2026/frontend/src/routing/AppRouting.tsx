import { createBrowserRouter, createRoutesFromElements, Route } from 'react-router';
import { Layout } from '../components/shared/Layout';
import { HomePage } from '../pages/AirplanesPage';
import { AddAirplanePage } from '../pages/AddAirplanePage';

export const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<Layout />}>
      <Route index element={<HomePage />} />
      <Route path="add" element={<AddAirplanePage />} />
    </Route>
  )
);
