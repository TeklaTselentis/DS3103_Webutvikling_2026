import { RouterProvider } from 'react-router';
import { AirplaneProvider } from './contexts/AirplaneContext';
import { router } from './routing/AppRouting';
import { Toaster } from './components/shared/sonner';

export default function App() {
  return (
    <AirplaneProvider>
      <RouterProvider router={router} />
      <Toaster position="top-right" />
    </AirplaneProvider>
  );
}
