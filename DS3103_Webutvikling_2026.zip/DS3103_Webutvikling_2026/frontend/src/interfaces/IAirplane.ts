export interface IAirplane {
  id?: number;
  modelName: string;
  category: string;
  passengers: number;
  image: string;
}
