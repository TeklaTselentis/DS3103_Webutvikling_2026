import axios from 'axios';
import { IAirplane } from '../interfaces/IAirplane';

const API_BASE_URL = 'http://localhost:5000/api/airplanes';
const IMAGE_UPLOAD_URL = 'http://localhost:5000/api/images';

class AirplaneService {

  async getAll(): Promise<IAirplane[]> {
    const response = await axios.get<IAirplane[]>(API_BASE_URL);
    return response.data;
  }

  async getById(id: number): Promise<IAirplane> {
    const response = await axios.get<IAirplane>(`${API_BASE_URL}/${id}`);
    return response.data;
  }

  async getByModelName(modelName: string): Promise<IAirplane[]> {
    const response = await axios.get<IAirplane[]>(`${API_BASE_URL}/search/modelname?name=${modelName}`);
    return response.data;
  }

  async uploadImage(imageFile: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', imageFile);
    const response = await axios.post<{ fileName: string }>(IMAGE_UPLOAD_URL, formData);
    return response.data.fileName;
  }

  async create(airplane: IAirplane, imageFile?: File): Promise<IAirplane> {
    let imageName = airplane.image;
    if (imageFile) {
      imageName = await this.uploadImage(imageFile);
    }
    const response = await axios.post<IAirplane>(API_BASE_URL, { ...airplane, image: imageName || '' });
    return response.data;
  }

  async update(id: number, airplane: IAirplane, imageFile?: File): Promise<IAirplane> {
    let imageName = airplane.image;
    if (imageFile) {
      imageName = await this.uploadImage(imageFile);
    }
    const response = await axios.put<IAirplane>(`${API_BASE_URL}/${id}`, { ...airplane, image: imageName || '' });
    return response.data;
  }

  async delete(id: number): Promise<void> {
    await axios.delete(`${API_BASE_URL}/${id}`);
  }
}

export default new AirplaneService();
