# AirIndustries — Webutvikling konteeksamen (DS3103 V2026)

En fullstack webapplikasjon for registrering og administrasjon av flymodeller. Brukere kan søke, legge til, redigere og slette fly, samt laste opp bilder tilknyttet hver modell.

## Funksjonalitet
- Se alle flymodeller i en liste
- Søk på modellnavn
- Legg til nye flymodeller med bilde
- Rediger eksisterende flymodeller
- Slett flymodeller
- Bildeopplasting til server

## Teknologier

**Frontend**
- React 18 / TypeScript
- Vite
- React Router v7
- Tailwind CSS
- Axios
- Sonner (toast-varsler)

**Backend**
- ASP.NET Core (.NET)
- Entity Framework Core
- SQLite
- Swagger / OpenAPI

## Oppsett

### Backend

```bash
cd backend
dotnet restore
dotnet run
```

API kjører på `http://localhost:5000`. Swagger-dokumentasjon tilgjengelig på `http://localhost:5000/swagger`.

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend kjører på `http://localhost:5173`.

## Krav
- .NET 8 SDK eller nyere
- Node.js 18+
