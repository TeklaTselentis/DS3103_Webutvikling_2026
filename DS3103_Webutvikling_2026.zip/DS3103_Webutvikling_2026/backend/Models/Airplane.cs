namespace AirplaneAPI.Models
{
    public class Airplane
    {
        public int Id { get; set; }
        public string ModelName { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public int Passengers { get; set; }
        public string? Image { get; set; }
    }
}
