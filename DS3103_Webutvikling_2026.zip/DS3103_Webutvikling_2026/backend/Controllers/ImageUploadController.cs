using Microsoft.AspNetCore.Mvc;

namespace AirplaneAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ImagesController : ControllerBase
    {
        private readonly IWebHostEnvironment _environment;
        private readonly ILogger<ImagesController> _logger;

        public ImagesController(IWebHostEnvironment environment, ILogger<ImagesController> logger)
        {
            _environment = environment;
            _logger = logger;
        }


        [HttpPost]
        public async Task<ActionResult<object>> UploadImage([FromForm] IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    return BadRequest(new { message = "No file uploaded" });
                }


                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
                var extension = Path.GetExtension(file.FileName).ToLowerInvariant();

                if (!allowedExtensions.Contains(extension))
                {
                    return BadRequest(new { message = "Invalid file type. Only image files are allowed." });
                }


                if (file.Length > 5 * 1024 * 1024)
                {
                    return BadRequest(new { message = "File size exceeds 5MB limit" });
                }


                var fileName = $"{Guid.NewGuid()}{extension}";
                var imagesPath = Path.Combine(_environment.WebRootPath, "images");


                if (!Directory.Exists(imagesPath))
                {
                    Directory.CreateDirectory(imagesPath);
                }

                var filePath = Path.Combine(imagesPath, fileName);


                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                _logger.LogInformation($"Image uploaded successfully: {fileName}");

                return Ok(new { 
                    message = "Image uploaded successfully", 
                    fileName = fileName,
                    url = $"/images/{fileName}"
                });
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error uploading image: {ex.Message}");
                return StatusCode(500, new { message = "An error occurred while uploading the image", error = ex.Message });
            }
        }


        [HttpDelete("{fileName}")]
        public ActionResult DeleteImage(string fileName)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(fileName))
                {
                    return BadRequest(new { message = "Filename is required" });
                }

                var imagesPath = Path.Combine(_environment.WebRootPath, "images");
                var filePath = Path.Combine(imagesPath, fileName);

                if (!System.IO.File.Exists(filePath))
                {
                    return NotFound(new { message = $"Image '{fileName}' not found" });
                }

                System.IO.File.Delete(filePath);

                _logger.LogInformation($"Image deleted successfully: {fileName}");

                return Ok(new { message = $"Image '{fileName}' has been deleted successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error deleting image: {ex.Message}");
                return StatusCode(500, new { message = "An error occurred while deleting the image", error = ex.Message });
            }
        }
    }
}
