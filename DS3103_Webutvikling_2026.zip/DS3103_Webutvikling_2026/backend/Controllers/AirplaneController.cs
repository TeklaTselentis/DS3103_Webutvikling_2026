using Microsoft.AspNetCore.Mvc;
using AirplaneAPI.Interfaces;
using AirplaneAPI.Models;

namespace AirplaneAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AirplanesController : ControllerBase
    {
        private readonly IAirplaneRepository _repository;

        public AirplanesController(IAirplaneRepository repository)
        {
            _repository = repository;
        }


        [HttpGet]
        public async Task<ActionResult<IEnumerable<Airplane>>> GetAllAirplanes()
        {
            try
            {
                var airplanes = await _repository.GetAllAirplanesAsync();
                return Ok(airplanes);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving airplanes", error = ex.Message });
            }
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<Airplane>> GetAirplaneById(int id)
        {
            try
            {
                if (id <= 0)
                {
                    return BadRequest(new { message = "Invalid airplane ID" });
                }

                var airplane = await _repository.GetAirplaneByIdAsync(id);
                
                if (airplane == null)
                {
                    return NotFound(new { message = $"Airplane with ID {id} not found" });
                }

                return Ok(airplane);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving the airplane", error = ex.Message });
            }
        }


        [HttpGet("search/modelname")]
        public async Task<ActionResult<IEnumerable<Airplane>>> GetAirplanesByModelName([FromQuery] string name)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(name))
                {
                    return BadRequest(new { message = "Model name cannot be empty" });
                }

                var airplanes = await _repository.GetAirplanesByModelNameAsync(name);
                
                if (!airplanes.Any())
                {
                    return NotFound(new { message = $"No airplanes found with model name containing '{name}'" });
                }

                return Ok(airplanes);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while searching for airplanes", error = ex.Message });
            }
        }


        [HttpPost]
        public async Task<ActionResult<Airplane>> CreateAirplane([FromBody] Airplane airplane)
        {
            try
            {
                if (airplane == null)
                {
                    return BadRequest(new { message = "Airplane data is required" });
                }

                if (string.IsNullOrWhiteSpace(airplane.ModelName))
                {
                    return BadRequest(new { message = "Model name is required" });
                }

                if (string.IsNullOrWhiteSpace(airplane.Category))
                {
                    return BadRequest(new { message = "Category is required" });
                }

                if (airplane.Passengers <= 0)
                {
                    return BadRequest(new { message = "Passengers must be greater than 0" });
                }

                var createdAirplane = await _repository.CreateAirplaneAsync(airplane);
                
                return CreatedAtAction(
                    nameof(GetAirplaneById), 
                    new { id = createdAirplane.Id }, 
                    createdAirplane
                );
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while creating the airplane", error = ex.Message });
            }
        }


        [HttpPut("{id}")]
        public async Task<ActionResult<Airplane>> UpdateAirplane(int id, [FromBody] Airplane airplane)
        {
            try
            {
                if (id <= 0)
                {
                    return BadRequest(new { message = "Invalid airplane ID" });
                }

                if (airplane == null)
                {
                    return BadRequest(new { message = "Airplane data is required" });
                }

                if (string.IsNullOrWhiteSpace(airplane.ModelName))
                {
                    return BadRequest(new { message = "Model name is required" });
                }

                if (string.IsNullOrWhiteSpace(airplane.Category))
                {
                    return BadRequest(new { message = "Category is required" });
                }

                if (airplane.Passengers <= 0)
                {
                    return BadRequest(new { message = "Passengers must be greater than 0" });
                }

                var updatedAirplane = await _repository.UpdateAirplaneAsync(id, airplane);
                
                if (updatedAirplane == null)
                {
                    return NotFound(new { message = $"Airplane with ID {id} not found" });
                }

                return Ok(updatedAirplane);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while updating the airplane", error = ex.Message });
            }
        }


        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAirplane(int id)
        {
            try
            {
                if (id <= 0)
                {
                    return BadRequest(new { message = "Invalid airplane ID" });
                }

                var deleted = await _repository.DeleteAirplaneAsync(id);
                
                if (!deleted)
                {
                    return NotFound(new { message = $"Airplane with ID {id} not found" });
                }

                return Ok(new { message = $"Airplane with ID {id} has been deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting the airplane", error = ex.Message });
            }
        }
    }
}
