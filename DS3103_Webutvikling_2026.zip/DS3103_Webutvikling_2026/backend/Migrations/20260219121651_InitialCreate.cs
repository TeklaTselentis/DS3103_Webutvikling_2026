﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace AirplaneAPI.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Airplanes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ModelName = table.Column<string>(type: "TEXT", nullable: false),
                    Category = table.Column<string>(type: "TEXT", nullable: false),
                    Passengers = table.Column<int>(type: "INTEGER", nullable: false),
                    Image = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Airplanes", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Airplanes",
                columns: new[] { "Id", "Category", "Image", "ModelName", "Passengers" },
                values: new object[,]
                {
                    { 1, "Private Jet", "teslaplane1.jpg", "TeslaPlane-1", 12 },
                    { 2, "Travel", "skymaster500.jpg", "SkyMaster-500", 180 },
                    { 3, "Military", "fighterjetx.jpg", "FighterJet-X", 2 },
                    { 4, "Private Jet", "luxurywing200.jpg", "LuxuryWing-200", 8 },
                    { 5, "Cargo", "cargomaster.jpg", "Cargo-Master", 4 },
                    { 6, "Travel", "airbusa380.jpg", "AirBus-A380", 550 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Airplanes");
        }
    }
}
