using Microsoft.EntityFrameworkCore;
using AirplaneAPI.Models;
using AirplaneAPI.Interfaces;

namespace AirplaneAPI.Contexts
{
    public class AirplaneContext : DbContext, IAirplaneRepository
    {
        public AirplaneContext(DbContextOptions<AirplaneContext> options) : base(options)
        {
        }

        public DbSet<Airplane> Airplanes { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Airplane>().HasData(
                new Airplane
                {
                    Id = 1,
                    ModelName = "TeslaPlane-1",
                    Category = "Private Jet",
                    Passengers = 12,
                    Image = "Light-Jets.jpg"
                },
                new Airplane
                {
                    Id = 2,
                    ModelName = "SkyMaster-500",
                    Category = "Travel",
                    Passengers = 180,
                    Image = "Light-Jets.jpg"
                },
                new Airplane
                {
                    Id = 3,
                    ModelName = "FighterJet-X",
                    Category = "Military",
                    Passengers = 2,
                    Image = "Light-Jets.jpg"
                },
                new Airplane
                {
                    Id = 4,
                    ModelName = "LuxuryWing-200",
                    Category = "Private Jet",
                    Passengers = 8,
                    Image = "Light-Jets.jpg"
                },
                new Airplane
                {
                    Id = 5,
                    ModelName = "Cargo-Master",
                    Category = "Cargo",
                    Passengers = 4,
                    Image = "Light-Jets.jpg"
                },
                new Airplane
                {
                    Id = 6,
                    ModelName = "AirBus-A380",
                    Category = "Travel",
                    Passengers = 550,
                    Image = "Light-Jets.jpg"
                }
            );
        }


        public async Task<IEnumerable<Airplane>> GetAllAirplanesAsync()
        {
            return await Airplanes.ToListAsync();
        }

        public async Task<Airplane?> GetAirplaneByIdAsync(int id)
        {
            return await Airplanes.FindAsync(id);
        }

        public async Task<IEnumerable<Airplane>> GetAirplanesByModelNameAsync(string modelName)
        {
            return await Airplanes
                .Where(a => a.ModelName.ToLower().Contains(modelName.ToLower()))
                .ToListAsync();
        }

        public async Task<Airplane> CreateAirplaneAsync(Airplane airplane)
        {
            Airplanes.Add(airplane);
            await SaveChangesAsync();
            return airplane;
        }

        public async Task<Airplane?> UpdateAirplaneAsync(int id, Airplane airplane)
        {
            var existingAirplane = await Airplanes.FindAsync(id);
            
            if (existingAirplane == null)
            {
                return null;
            }

            existingAirplane.ModelName = airplane.ModelName;
            existingAirplane.Category = airplane.Category;
            existingAirplane.Passengers = airplane.Passengers;
            
            if (!string.IsNullOrEmpty(airplane.Image))
            {
                existingAirplane.Image = airplane.Image;
            }

            await SaveChangesAsync();
            return existingAirplane;
        }

        public async Task<bool> DeleteAirplaneAsync(int id)
        {
            var airplane = await Airplanes.FindAsync(id);
            
            if (airplane == null)
            {
                return false;
            }

            Airplanes.Remove(airplane);
            await SaveChangesAsync();
            return true;
        }
    }
}
