using AirplaneAPI.Models;

namespace AirplaneAPI.Interfaces
{
    public interface IAirplaneRepository
    {
        Task<IEnumerable<Airplane>> GetAllAirplanesAsync();
        Task<Airplane?> GetAirplaneByIdAsync(int id);
        Task<IEnumerable<Airplane>> GetAirplanesByModelNameAsync(string modelName);
        Task<Airplane> CreateAirplaneAsync(Airplane airplane);
        Task<Airplane?> UpdateAirplaneAsync(int id, Airplane airplane);
        Task<bool> DeleteAirplaneAsync(int id);
    }
}
